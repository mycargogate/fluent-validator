package ch.mycargogate.fluentValidator;
public class App { public static void main(String[] args){ System.out.println("Demo"); } }
