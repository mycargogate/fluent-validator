package ch.mycargogate.fluentValidator;

public class DefaultRegistry<T> implements CustomRegistry<T> {}
