package ch.mycargogate.fluentValidator;
// shortened placeholder for full_validator_java
public class Validator<T> { }
