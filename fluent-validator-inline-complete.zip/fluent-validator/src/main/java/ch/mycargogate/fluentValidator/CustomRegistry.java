package ch.mycargogate.fluentValidator;

public interface CustomRegistry<T> {}
