package ch.mycargogate.fluentValidator;
public class ValidatorReaderCSV<T> { }
