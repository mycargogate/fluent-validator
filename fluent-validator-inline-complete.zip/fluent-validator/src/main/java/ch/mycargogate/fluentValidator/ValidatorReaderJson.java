package ch.mycargogate.fluentValidator;
public class ValidatorReaderJson<T> { }
