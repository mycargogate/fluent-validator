package ch.mycargogate.fluentValidator;
public class ValidatorReaderJsonTest { }
