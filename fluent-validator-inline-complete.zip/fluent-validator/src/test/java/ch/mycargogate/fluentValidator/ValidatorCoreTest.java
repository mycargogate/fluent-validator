package ch.mycargogate.fluentValidator;
public class ValidatorCoreTest { }
